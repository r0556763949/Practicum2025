
const ClientContent = () => {
    return (
        <div >
            <h2 >Content goes here...</h2>
        </div>
    );
};


export default ClientContent;