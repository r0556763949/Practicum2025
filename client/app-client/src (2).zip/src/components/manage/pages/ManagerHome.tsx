
import ClientList from "../home/ClientList";

const ManagerHome = () => {
  return (
    <><ClientList/></>
  );
};

export default ManagerHome;

