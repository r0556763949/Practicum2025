export interface ClientDto {
    id: number;
    name: string;
    address?: string;
    email: string;
    phone?: string;
    role: string;
  }